INSERT INTO suppliers (name,address,registration_no) VALUES ('Amila', 'Colombo', 10);

INSERT INTO suppliers (name,address,registration_no) VALUES ('Kasun', 'Gampaha', 20);

INSERT INTO suppliers (name,address,registration_no) VALUES ('Nalaka', 'Galle', 30);