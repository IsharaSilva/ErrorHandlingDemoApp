package com.navulia.errorhandlingdemo.utility;

public class SupplierErrorMessages {
    public static final String ERROR_SUPPLIER_EXISTS = "Supplier Already Exists";

}
