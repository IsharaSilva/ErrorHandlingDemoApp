package com.navulia.genericerrorhandler.utility;

public class ErrorMessages {

    public static final String ERROR_RESOURCE_NOT_FOUND = "Resource Not Found";

}
