#First go to the generic-error-handler project and run "mvn clean package" command
#Then you can see than .jar file under your target folder.
#After that copy that .jar file and paste it where you prefer.
#Then add that .jar file to your local maven repository and add it as depency in to your spring boot pom.xml file.
#Please refer below link to get guidance
https://xitricon.sharepoint.com/:w:/r/sites/NavuliaNewDevelopment/_layouts/15/Doc.aspx?sourcedoc=%7BB712FB01-880A-4F56-827D-D3372162F9D2%7D&file=Externalize%20Error%20Handling%20as%20a%20Common%20Module.docx&action=default&mobileredirect=true